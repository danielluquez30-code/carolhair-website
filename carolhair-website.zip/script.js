function enviar() {
  document.getElementById('form').style.display = 'none';
  document.getElementById('mensaje').classList.remove('hidden');
}
